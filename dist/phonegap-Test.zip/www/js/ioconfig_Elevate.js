/* Copyright(c) 2016, iovation, inc. All rights reserved. */
console.log("Inside iovation black box script");
window.io_global_object_name = "IGLOO"
window.IGLOO = window.IGLOO || {
  "enable_flash" : false,
  /*"bbout_element_id": "ioBlackBox", // Way to set black box data in an html element */
  "bb_callback": function ( bb, complete ) {
	localStorage.setItem("io-black-box", bb);
	console.log( "Black box data : " + bb );
	},
  "loader": {
    "uri_hook" : "../www/js/",
    "version": "general5",
    "subkey" : "5FExse+oA1134BhiwCF2EeQ1TfisPJGha4CpVG2nd7E=",
    "trace_handler": function ( msg ) {
      console.log( "iovation bb : " + msg );
    }
  }
};
